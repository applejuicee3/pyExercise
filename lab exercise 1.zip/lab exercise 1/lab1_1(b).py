sum_of_numbers = sum(range(50, 101))
print("The sum of all numbers from 50 to 100 is:", sum_of_numbers)
