for num in range(20, 41):
    square = num ** 2
    print(f"The square of {num} is {square}")

